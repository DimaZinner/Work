﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BrewBDApp
{
    public partial class DeleteWindow : Window
    {
        private string tableName;
        private DatabaseHelper dbHelper;
        private MainWindow mainWindow;

        public DeleteWindow(string tableName, DatabaseHelper dbHelper, MainWindow mainWindow)
        {
            InitializeComponent();
            this.tableName = tableName;
            this.dbHelper = dbHelper;
            this.mainWindow = mainWindow;
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (int.TryParse(IDTextBox.Text, out int id))
                {
                    string primaryKeyColumn = GetPrimaryKeyColumn(tableName);

                    if (primaryKeyColumn != null)
                    {
                        if (CheckRecordExists(tableName, primaryKeyColumn, id))
                        {
                            string deleteQuery = $"DELETE FROM {tableName} WHERE {primaryKeyColumn.Replace(" ", "_")} = @ID";
                            SqlParameter parameter = new SqlParameter("@ID", id);
                            dbHelper.ExecuteNonQuery(deleteQuery, new SqlParameter[] { parameter });

                            MessageBox.Show("Запись успешно удалена.");
                            this.Close(); // Закрываем окно после успешного удаления записи

                            mainWindow.UpdateDataGrid(); // Обновляем данные в MainWindow
                        }
                        else
                        {
                            MessageBox.Show("Запись с указанным ID не найдена.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Не удалось определить первичный ключ для таблицы.");
                    }
                }
                else
                {
                    MessageBox.Show("Введите корректное числовое значение для ID.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private string GetPrimaryKeyColumn(string tableName)
        {
            string query = $"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = @TableName AND OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + '.' + CONSTRAINT_NAME), 'IsPrimaryKey') = 1";
            SqlParameter parameter = new SqlParameter("@TableName", tableName);
            object result = dbHelper.ExecuteScalar(query, new SqlParameter[] { parameter });
            return result?.ToString().Replace("_", " ");
        }

        private bool CheckRecordExists(string tableName, string primaryKeyColumn, int id)
        {
            string query = $"SELECT COUNT(*) FROM {tableName} WHERE {primaryKeyColumn.Replace(" ", "_")} = @ID";
            SqlParameter parameter = new SqlParameter("@ID", id);
            int count = (int)dbHelper.ExecuteScalar(query, new SqlParameter[] { parameter });
            return count > 0;
        }
    }
}
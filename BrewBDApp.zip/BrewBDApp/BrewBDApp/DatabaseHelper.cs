﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Controls;
using System.Windows;
using System.Security.Cryptography;

public class DatabaseHelper
{
    private string connectionString;

    public DatabaseHelper(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public void ExecuteNonQuery(string query, SqlParameter[] parameters = null)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand(query, connection);
            if (parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }
            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    public DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand(query, connection);
            if (parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }
            connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable result = new DataTable();
            adapter.Fill(result);
            return result;
        }
    }

    public void InsertRecord(string tableName, List<SqlParameter> parameters)
    {
        try
        {
            var columnNames = parameters.Select(p => p.ParameterName.Substring(1));
            string columns = string.Join(", ", columnNames);
            string values = string.Join(", ", columnNames.Select(c => "@" + c));
            string insertQuery = $"INSERT INTO {tableName} ({columns}) VALUES ({values})";
            ExecuteNonQuery(insertQuery, parameters.ToArray());
        }
        catch (Exception ex)
        {
            throw new Exception("Error inserting record: " + ex.Message);
        }
    }

    public void DeleteRecord(string tableName, string condition)
    {
        try
        {
            string deleteQuery = $"DELETE FROM {tableName} WHERE {condition}";
            ExecuteNonQuery(deleteQuery);
        }
        catch (Exception ex)
        {
            throw new Exception("Error deleting record: " + ex.Message);
        }
    }
    public void UpdateRecord(string tableName, Dictionary<string, object> setValues, string condition, List<SqlParameter> parameters = null)
    {
        try
        {
            // Проверяем, что есть значения для обновления
            if (setValues.Count > 0)
            {
                // Формируем строку SET для запроса
                string setClause = string.Join(", ", setValues.Select(kv => $"{kv.Key} = @{kv.Key}"));
                string updateQuery = $"UPDATE {tableName} SET {setClause} WHERE {condition}";

                // Создаем команду SQL
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        // Добавляем параметры
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters.ToArray());
                        }

                        // Вывод отладочной информации
                        Console.WriteLine($"SQL Query: {updateQuery}");
                        if (parameters != null)
                        {
                            foreach (var param in parameters)
                            {
                                Console.WriteLine($"Parameter: {param.ParameterName} = {param.Value}");
                            }
                        }

                        // Выполняем запрос
                        command.ExecuteNonQuery();
                    }
                }
            }
            else
            {
                Console.WriteLine("No values to update.");
            }
        }
        catch (Exception ex)
        {
            // Выводим сообщение об ошибке в консоль
            Console.WriteLine("Error: " + ex.Message);
            throw new Exception("Error updating record: " + ex.Message);
        }
    }



    public bool CheckRecordExists(string tableName, string idColumnName, int id)
    {
        try
        {
            string query = $"SELECT COUNT(*) FROM {tableName} WHERE {idColumnName} = @ID";
            SqlParameter parameter = new SqlParameter("@ID", id);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.Add(parameter);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message);
            return false;
        }
    }

    public object ExecuteScalar(string query, SqlParameter[] parameters = null)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand(query, connection);
            if (parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }
            connection.Open();
            return command.ExecuteScalar();
        }
    }



}

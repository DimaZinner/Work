﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace BrewBDApp
{
    public partial class MainWindow : Window
    {
        private DatabaseHelper dbHelper;
        public string selectedTable;
        private DataTable mainDataTable;
        private int rowIndex;

        public DataTable MainDataTable
        {
            get { return mainDataTable; }
        }

        public MainWindow()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper("Data Source=DESKTOP-KG3VQL0;Initial Catalog=Brewings;Integrated Security=True");
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            FillTableNames();
            dataGrid.SelectionChanged += DataGrid_SelectionChanged;
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            rowIndex = dataGrid.SelectedIndex;
        }

        private void FillTableNames()
        {
            try
            {
                string query = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_NAME != 'sysdiagrams'";
                DataTable tables = dbHelper.ExecuteQuery(query);
                TableComboBox.ItemsSource = tables.DefaultView;
                TableComboBox.DisplayMemberPath = "TABLE_NAME";
                TableComboBox.SelectedValuePath = "TABLE_NAME";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        public void UpdateDataGrid()
        {
            if (!string.IsNullOrEmpty(selectedTable))
            {
                mainDataTable = dbHelper.ExecuteQuery($"SELECT * FROM {selectedTable}");
                dataGrid.ItemsSource = mainDataTable.DefaultView;
            }
        }

        private void TableComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TableComboBox.SelectedItem != null)
            {
                selectedTable = TableComboBox.SelectedValue.ToString();
                UpdateDataGrid();
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedTable))
            {
                var addWindow = new AddWindow(selectedTable, dbHelper, this);
                addWindow.Show();
            }
            else
            {
                MessageBox.Show("Please select a table first.");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedTable))
            {
                var deleteWindow = new DeleteWindow(selectedTable, dbHelper, this);
                deleteWindow.Show();
            }
            else
            {
                MessageBox.Show("Please select a table first.");
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedTable))
            {
                if (dataGrid.SelectedItem != null)
                {
                    DataRowView selectedRow = (DataRowView)dataGrid.SelectedItem;
                    DataTable tableSchema = dbHelper.ExecuteQuery($"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{selectedTable}'");

                    int rowIndex = mainDataTable.Rows.IndexOf(selectedRow.Row);

                    if (rowIndex >= 0)
                    {
                        // Получаем имя первичного ключа из схемы таблицы
                        string primaryKeyColumnName = tableSchema.AsEnumerable()
                            .Where(row => row.Field<string>("COLUMN_NAME").StartsWith("ID_"))
                            .Select(row => row.Field<string>("COLUMN_NAME"))
                            .FirstOrDefault();

                        var editWindow = new EditWindow(tableSchema, dbHelper, selectedRow, this, primaryKeyColumnName, dataGrid, mainDataTable, rowIndex);
                        editWindow.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Invalid row index.");
                    }
                }
                else
                {
                    MessageBox.Show("Please select a record to edit.");
                }
            }
            else
            {
                MessageBox.Show("Please select a table first.");
            }
        }
    }
}
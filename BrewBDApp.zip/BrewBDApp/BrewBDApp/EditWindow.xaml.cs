﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Security.Cryptography;

namespace BrewBDApp
{
    public partial class EditWindow : Window
    {
        private DataTable tableSchema;
        private DatabaseHelper dbHelper;
        private DataRowView selectedRow;
        private MainWindow mainWindow;
        private string primaryKeyColumnName;
        private DataGrid dataGrid;
        private DataTable mainDataTable;
        private int rowIndex;
        private string selectedTable;
        private TextBox[] formFields;
        private object primaryKeyValue;

        public EditWindow(DataTable tableSchema, DatabaseHelper dbHelper, DataRowView selectedRow, MainWindow mainWindow, string primaryKeyColumnName, DataGrid dataGrid, DataTable mainDataTable, int rowIndex)
        {
            InitializeComponent();
            this.tableSchema = tableSchema;
            this.dbHelper = dbHelper;
            this.selectedRow = selectedRow;
            this.mainWindow = mainWindow;
            this.primaryKeyColumnName = primaryKeyColumnName;
            this.dataGrid = dataGrid;
            this.mainDataTable = mainDataTable;
            this.rowIndex = rowIndex;
            this.selectedTable = mainWindow.selectedTable;

            LoadData();
        }

        private void LoadData()
        {
            formFields = new TextBox[tableSchema.Rows.Count];
            for (int i = 0; i < tableSchema.Rows.Count; i++)
            {
                DataRow column = tableSchema.Rows[i];
                string columnName = column["COLUMN_NAME"].ToString();

                Label label = new Label
                {
                    Content = columnName
                };
                FormStackPanel.Children.Add(label);

                string safeColumnName = columnName.Replace(" ", "_"); // Заменяем пробелы на подчеркивания
                TextBox textBox = new TextBox
                {
                    Name = safeColumnName,
                    Text = selectedRow[columnName].ToString()
                };

                // Сохраняем значение первичного ключа
                if (columnName == primaryKeyColumnName)
                {
                    primaryKeyValue = selectedRow[columnName];
                }

                formFields[i] = textBox;
                FormStackPanel.Children.Add(textBox);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string updateQuery = $"UPDATE {selectedTable} SET ";

                // Получаем имя первичного ключа из схемы таблицы
                var primaryKeyColumn = tableSchema.AsEnumerable()
                    .Where(row => row.Field<string>("COLUMN_NAME") == primaryKeyColumnName)
                    .FirstOrDefault();

                if (primaryKeyColumn != null)
                {
                    string primaryKeyColumnNameInDatabase = primaryKeyColumn["COLUMN_NAME"].ToString();

                    // Проверяем, что имя первичного ключа в базе данных совпадает с ожидаемым
                    if (primaryKeyColumnNameInDatabase != primaryKeyColumnName)
                    {
                        throw new Exception($"Primary key column name mismatch. Expected: {primaryKeyColumnName}, Actual: {primaryKeyColumnNameInDatabase}");
                    }
                }
                else
                {
                    throw new Exception($"Primary key column '{primaryKeyColumnName}' not found in table schema.");
                }
                var parameters = new List<SqlParameter>();

                for (int i = 0; i < formFields.Length; i++)
                {
                    if (formFields[i].Name != primaryKeyColumnName)
                    {
                        updateQuery += $"{formFields[i].Name} = @{formFields[i].Name}, ";
                        parameters.Add(new SqlParameter($"@{formFields[i].Name}", formFields[i].Text));
                    }
                }

                updateQuery = updateQuery.TrimEnd(',', ' ');
                updateQuery += $" WHERE {primaryKeyColumnName} = @{primaryKeyColumnName}";
                parameters.Add(new SqlParameter($"@{primaryKeyColumnName}", primaryKeyValue));

                dbHelper.ExecuteNonQuery(updateQuery, parameters.ToArray());
                mainWindow.UpdateDataGrid();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

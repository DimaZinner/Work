﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BrewBDApp
{
    public partial class AddWindow : Window
    {
        private string tableName;
        private DatabaseHelper dbHelper;
        private MainWindow mainWindow;

        public AddWindow(string tableName, DatabaseHelper dbHelper, MainWindow mainWindow)
        {
            InitializeComponent();
            this.tableName = tableName;
            this.dbHelper = dbHelper;
            this.mainWindow = mainWindow;
            FillColumnNames();
        }

        private void FillColumnNames()
        {
            try
            {
                string query = $"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{tableName}'";
                var columns = dbHelper.ExecuteQuery(query);
                foreach (DataRow row in columns.Rows)
                {
                    string columnName = row["COLUMN_NAME"].ToString().Replace("_", " ");

                    if (!IsAutoIncrementColumn(tableName, columnName))
                    {
                        var panel = new StackPanel();
                        panel.Orientation = Orientation.Horizontal;

                        var label = new Label();
                        label.Content = columnName;
                        label.Margin = new Thickness(5);

                        var textBox = new TextBox();
                        textBox.Name = "input_" + columnName.Replace(" ", "_");
                        textBox.Margin = new Thickness(5);

                        panel.Children.Add(label);
                        panel.Children.Add(textBox);
                        InputStackPanel.Children.Add(panel);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private bool IsAutoIncrementColumn(string tableName, string columnName)
        {
            string query = $"SELECT COLUMNPROPERTY(object_id('{tableName}'), '{columnName.Replace(" ", "_")}', 'IsIdentity')";
            object result = dbHelper.ExecuteQuery(query).Rows[0][0];
            return (result != DBNull.Value && (int)result == 1);
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var parameters = new List<SqlParameter>();
                foreach (var item in InputStackPanel.Children)
                {
                    if (item is StackPanel stackPanel)
                    {
                        foreach (var innerItem in stackPanel.Children)
                        {
                            if (innerItem is TextBox textBox)
                            {
                                string columnName = textBox.Name.Replace("input_", "").Replace("_", " ");
                                parameters.Add(new SqlParameter($"@{columnName.Replace(" ", "_")}", textBox.Text));
                            }
                        }
                    }
                }

                dbHelper.InsertRecord(tableName, parameters);
                this.Close(); // Закрываем окно после успешного добавления записи

                mainWindow.UpdateDataGrid(); // Обновляем данные в MainWindow
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}